from os import (system as System, popen)



for valor in range(10, 1000):
    comando = f"echo {valor}"
    executa_script = "python -OO atividades/savio-alves_mini_caixa_eletronico.py"
    
    resultado = popen(executa_script, mode="w")
    resultado.write(str(valor))
    saida = resultado.close()
    
    if saida is None:
        print(f"Foi sucedido para {valor}.")