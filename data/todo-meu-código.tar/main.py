

print(input("Escolha: "))