"""
   Vamos fazer uma versão simplificada do joguinho da velha(tic-tac-toe).
 Ele será feito usando o terminal, com o console compartilhado. O tabuleiro
 haverá coordenadas que você pode dizer onde jogar.
"""
from enum import (StrEnum, auto)
from time import (time)
from unittest import(TestCase)
from random import (choice)

class Peca(StrEnum):
    BOLA = 'O'
    XIS = 'X'

    def __repr__(self) -> str:
        match self:
            case Peca.BOLA:
                return "O "
            case Peca.XIS:
                return "X "
                    
    def __str__(self):
        match self:
            case Peca.BOLA:
                return 'Bola(O)'
            case Peca.XIS:
                return "Xis(X)"


class Jogador:
    # Contagem de instância(jogadores) criados.
    INSTANCIAS = 0

    def __init__(self, peca: Peca) -> None:
        assert isinstance(peca, Peca)

        self.inicio = time()
        self.tempo_medio_de_jogada = 0.0
        self.jogadas = []
        self.peca = peca
        Jogador.INSTANCIAS += 1
    
    def __str__(self):
        decorrido = abs(time() - self.inicio)
        jogadas = len(self.jogadas)

        return f"Jogador com {self.peca}; iniciou à {decorrido:0.2}seg; realizou {jogadas} jogadas."


class Tabuleiro:
    def __init__(self):
        self.formatacao = """
                    1      2      3
               
                        *     *
             A      %s  *  %s *   %s
                        *     *
                 **********************
                        *     *
             B      %s  *  %s *   %s
                        *     *                                                
                 **********************
                        *     *
             C      %s  *  %s *   %s
                        *     *                                                

            """
        self.grade = (
            [None, None, None],
            [None, None, None],
            [None, None, None]
        )

    def __str__(self):
        # Conversão da matriz numa sequência.
        sequencia = tuple(self.grade[0]) + tuple(self.grade[1]) + tuple(self.grade[2])
        # Conversão de peças em suas respectívas representações:
        CLOSURE = lambda X: "  " if X is None else repr(X)
        tupla = tuple(map(CLOSURE, sequencia))

        return self.formatacao % tupla

    @staticmethod
    def decodifica(codigo) -> tuple[int, int]:
        assert len(codigo) == 2
        assert codigo[0].upper() in "ABC"
        assert codigo[1] in "123"

        match codigo[0].upper():
            case "A": linha = 0
            case "B": linha = 1
            case "C": linha = 2
            case _:
                raise AttributeError("Não aceito!")
            
        match codigo[1]:
            case "1": coluna = 0
            case "2": coluna = 1
            case "3": coluna = 2
            case _:
                raise AttributeError("Não aceito!")
        return (linha, coluna)
        
    def coloca_peca(self, peca: Peca, linha: int, coluna: int) -> bool:
        (L, C) = (linha, coluna)

        if self.grade[L][C] is None:
            self.grade[L][C] = peca
            return True
        else:
            return False
    
    def verifica_vencedor(self) -> tuple[Peca, bool]:
        matriz = self.grade
        
        # Tabuleiro nomeada, cada lugar nomeada de 'a' à 'i', isso, começando de cima prá baixo e
        # da esquerda à direita.
        #        a  |  b  |  c
        #      -----------------
        #        d  |  e  |  f
        #      -----------------
        #        g  |  h  |  i
        (a, b, c) = matriz[0][:]
        (d, e, f) = matriz[1][:]
        (g, h, i) = matriz[2][:]
        
        # Primeira parte todas as linhas.
        if (a is not None) and (a == b == c):
            vencedor = a
            alguem_venceu = True
        elif (d is not None) and (d == e == f):
            vencedor = d
            alguem_venceu = True
        elif (g is not None) and (g == h == i):
            vencedor = g
            alguem_venceu = True
        # Segunda verificação é das colunas.
        elif (a is not None) and (a == d == g):
            vencedor = a
            alguem_venceu = True
        elif (b is not None) and (b == e == h):
            vencedor = b
            alguem_venceu = True
        elif (c is not None) and (c == f == i):
            vencedor = c
            alguem_venceu = True
        # Terceiro, verificação das diagonais:
        elif (a is not None) and (a == e == i):
            vencedor = a
            alguem_venceu = True
        elif (c is not None) and (c == e == g):
            vencedor = c
            alguem_venceu = True
        else:
            vencedor = None
            alguem_venceu = False

        return (vencedor, alguem_venceu)
        
"""
*** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** ***
                                    Testes Unitários
*** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** 
"""
class PecaRepresentacao(TestCase):
    def runTest(self):
        a = Peca.XIS
        b = Peca.BOLA
        c = Peca.BOLA

        print(a, b, c)

class OperacoesSobrePeca(TestCase):
    def runTest(self):
        a = Peca.XIS
        b = Peca.BOLA
        c = Peca.BOLA

        self.assertEqual(c, b)
        self.assertFalse(a == b or a == c)

class RepresentacaoDoJogador(TestCase):
    def runTest(self):
        obj = Jogador(Peca.BOLA)
        outro = Jogador(Peca.BOLA)

        print(obj, outro, sep='\n')

class RepresentacaoDoTabuleiro(TestCase):
    def runTest(self):
        obj = Tabuleiro()

        print(obj)
        obj.coloca_peca(Peca.BOLA, 0, 1)
        obj.coloca_peca(Peca.BOLA, 0, 2)
        obj.coloca_peca(Peca.XIS, 2, 1)
        obj.coloca_peca(Peca.XIS, 1, 1)
        obj.coloca_peca(Peca.XIS, 2, 2)
        print(obj)

class FuncaoDeDecodificacao(TestCase):
    def runTest(self):
        entradas = ["a1", "b2", "c3", "b3"]

        for item in entradas:
            print(item, "===>", Tabuleiro.decodifica(item))

class ConfiguracoesVencedoras(TestCase):
    @staticmethod
    def seleciona_uma_posicao() -> str:
        return choice("abc") + choice("123")
    
    def arranja_uma_configuracao_aleatoria(self):
        board = self.board
        contagem = 0
        PECAS = (Peca.BOLA, Peca.XIS)

        while contagem < 9:
            coordenadas = ConfiguracoesVencedoras.seleciona_uma_posicao() 
            (lin, col) = Tabuleiro.decodifica(coordenadas)
            peca = choice(PECAS)

            if board.coloca_peca(peca, lin, col):
                contagem += 1
        
    
    def setUp(self):
        self.board = Tabuleiro()

        print("Preenchendo ele, ...", end=" ")
        self.arranja_uma_configuracao_aleatoria()
        print("feito.")

    def runTest(self):
        print(self.board)
        print(f"Venceu?{self.board.verifica_vencedor()}")